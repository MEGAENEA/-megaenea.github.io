"""
DesktopToggle - Nasconde/mostra le icone del desktop con un click o Ctrl+B
Usa solo API Windows native - nessun driver a basso livello.
"""

import ctypes
import ctypes.wintypes
import threading
from PIL import Image, ImageDraw
import pystray

# ──────────────────────────────────────────────
# Windows API
# ──────────────────────────────────────────────
user32 = ctypes.windll.user32

MOD_CONTROL = 0x0002
VK_B        = 0x42
HOTKEY_ID   = 1
WM_HOTKEY   = 0x0312
WM_QUIT     = 0x0012


def get_desktop_listview():
    """Trova SysListView32 che contiene le icone del desktop."""
    progman = user32.FindWindowW("Progman", None)
    defview = user32.FindWindowExW(progman, None, "SHELLDLL_DefView", None)
    if defview:
        return user32.FindWindowExW(defview, None, "SysListView32", None)

    # Fallback WorkerW (Windows 10/11)
    result = ctypes.c_void_p(None)

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def callback(hwnd, _):
        child = user32.FindWindowExW(hwnd, None, "SHELLDLL_DefView", None)
        if child:
            result.value = user32.FindWindowExW(hwnd, None, "SysListView32", None)
        return True

    user32.EnumWindows(callback, None)
    return result.value


def set_desktop_icons(visible: bool):
    hwnd = get_desktop_listview()
    if hwnd:
        user32.ShowWindow(hwnd, 5 if visible else 0)


# ──────────────────────────────────────────────
# Stato
# ──────────────────────────────────────────────
state  = {"visible": False}
_icon_ref = {}   # riferimento all'icona tray accessibile dal thread hotkey


def toggle_desktop():
    state["visible"] = not state["visible"]
    set_desktop_icons(state["visible"])
    icon = _icon_ref.get("icon")
    if icon:
        icon.title = "Desktop: " + ("VISIBILE" if state["visible"] else "NASCOSTO")
        icon.icon  = make_icon(state["visible"])


# ──────────────────────────────────────────────
# Hotkey con RegisterHotKey (API nativa Windows)
# Nessun driver, nessun hook globale aggressivo
# ──────────────────────────────────────────────
def hotkey_listener():
    """Thread dedicato al message loop per Ctrl+B."""
    ok = user32.RegisterHotKey(None, HOTKEY_ID, MOD_CONTROL, VK_B)
    if not ok:
        return  # hotkey già registrata da un'altra app, si rinuncia silenziosamente

    msg = ctypes.wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
        if msg.message == WM_HOTKEY and msg.wParam == HOTKEY_ID:
            toggle_desktop()
        elif msg.message == WM_QUIT:
            break

    user32.UnregisterHotKey(None, HOTKEY_ID)


# ──────────────────────────────────────────────
# Icona tray
# ──────────────────────────────────────────────
def make_icon(visible: bool) -> Image.Image:
    size = 64
    img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    color = (46, 204, 113) if visible else (108, 117, 125)
    draw.ellipse([4, 4, size - 4, size - 4], fill=color)

    # Monitor stilizzato
    draw.rectangle([14, 18, 50, 38], fill=(255, 255, 255))
    draw.rectangle([26, 38, 38, 44], fill=(255, 255, 255))
    draw.rectangle([20, 44, 44, 46], fill=(255, 255, 255))

    if not visible:
        draw.line([10, 10, 54, 54], fill=(220, 53, 69), width=6)

    return img


# ──────────────────────────────────────────────
# Menu
# ──────────────────────────────────────────────
def on_toggle(icon, item):
    toggle_desktop()


def on_exit(icon, item):
    set_desktop_icons(True)   # ripristina le icone all'uscita
    icon.stop()


menu = pystray.Menu(
    pystray.MenuItem(
        lambda item: "Nascondi icone" if state["visible"] else "Mostra icone",
        on_toggle,
        default=True,
    ),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem("Esci", on_exit),
)


# ──────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────
def main():
    set_desktop_icons(False)
    state["visible"] = False

    icon = pystray.Icon(
        "DesktopToggle",
        make_icon(False),
        "Desktop: NASCOSTO",
        menu,
    )
    _icon_ref["icon"] = icon

    # Avvia listener hotkey in un thread separato
    ht = threading.Thread(target=hotkey_listener, daemon=True)
    ht.start()

    icon.run()


if __name__ == "__main__":
    main()
