# DesktopToggle - Script di installazione automatica
# Eseguire come Amministratore!

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "  DesktopToggle - Installazione" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

# 1. Controlla Python
Write-Host "[1/5] Controllo Python..." -ForegroundColor Yellow
try {
    $pythonVersion = python --version 2>&1
    Write-Host "      OK: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "      ERRORE: Python non trovato!" -ForegroundColor Red
    Write-Host "      Scarica Python da: https://www.python.org/downloads/" -ForegroundColor Red
    Write-Host "      IMPORTANTE: spunta 'Add Python to PATH' durante l'installazione!" -ForegroundColor Red
    Read-Host "Premi Invio per uscire"
    exit 1
}

# 2. Installa dipendenze
Write-Host "[2/5] Installazione librerie Python..." -ForegroundColor Yellow
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
pip install -r "$scriptDir\requirements.txt" --quiet
if ($LASTEXITCODE -eq 0) {
    Write-Host "      OK: librerie installate" -ForegroundColor Green
} else {
    Write-Host "      ERRORE durante installazione librerie" -ForegroundColor Red
    Read-Host "Premi Invio per uscire"
    exit 1
}

# 3. Crea cartella nel profilo utente
Write-Host "[3/5] Copia file nella cartella utente..." -ForegroundColor Yellow
$installDir = "$env:USERPROFILE\DesktopToggle"
New-Item -ItemType Directory -Force -Path $installDir | Out-Null
Copy-Item "$scriptDir\desktop_toggle.py" "$installDir\desktop_toggle.py" -Force
Write-Host "      OK: file copiato in $installDir" -ForegroundColor Green

# 4. Crea file .vbs per avvio silenzioso (senza finestra nera del terminale)
Write-Host "[4/5] Creazione launcher silenzioso..." -ForegroundColor Yellow
$vbsContent = @"
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "pythonw ""$installDir\desktop_toggle.py""", 0, False
"@
$vbsPath = "$installDir\DesktopToggle.vbs"
$vbsContent | Out-File -FilePath $vbsPath -Encoding ASCII
Write-Host "      OK: launcher creato" -ForegroundColor Green

# 5. Aggiunge all'avvio automatico di Windows
Write-Host "[5/5] Aggiunta all'avvio automatico di Windows..." -ForegroundColor Yellow
$startupFolder = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
$shortcutPath = "$startupFolder\DesktopToggle.lnk"

$WshShell = New-Object -ComObject WScript.Shell
$shortcut = $WshShell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $vbsPath
$shortcut.WorkingDirectory = $installDir
$shortcut.Description = "DesktopToggle - Nascondi icone desktop"
$shortcut.Save()

Write-Host "      OK: aggiunto all'avvio automatico" -ForegroundColor Green

Write-Host ""
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "  Installazione completata!" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  - Il programma si avviera' ad ogni accensione del PC" -ForegroundColor White
Write-Host "  - Icona nel system tray (barra in basso a destra)" -ForegroundColor White
Write-Host "  - Click sull'icona o Ctrl+B per toggle" -ForegroundColor White
Write-Host "  - All'avvio le icone del desktop saranno NASCOSTE" -ForegroundColor White
Write-Host ""

$avvia = Read-Host "Vuoi avviarlo adesso? (s/n)"
if ($avvia -eq "s" -or $avvia -eq "S") {
    Start-Process "wscript.exe" -ArgumentList "`"$vbsPath`""
    Write-Host "Avviato! Cerca l'icona nel system tray." -ForegroundColor Green
}

Read-Host "Premi Invio per chiudere"
