@echo off
:: Avvia lo script PowerShell come amministratore
powershell -Command "Start-Process powershell -ArgumentList '-ExecutionPolicy Bypass -File ""%~dp0installa.ps1""' -Verb RunAs"
